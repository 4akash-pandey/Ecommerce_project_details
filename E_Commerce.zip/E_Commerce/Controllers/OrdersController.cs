﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using E_Commerce.Models;

namespace E_Commerce.Controllers
{
    public class OrdersController : Controller
    {
        private ProjectTAAUEntities db = new ProjectTAAUEntities();
        
        public ActionResult Order()
        {
            return View();
        }

        // GET: Orders
        public ActionResult Index()
        {
            var orderTables = db.OrderTables.Include(o => o.Customer).Include(o => o.OrderStatu).Include(o => o.PaymentStatu).Include(o => o.Product);
            return View(orderTables.ToList());
        }

        // GET: Orders/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            OrderTable orderTable = db.OrderTables.Find(id);
            if (orderTable == null)
            {
                return HttpNotFound();
            }
            return View(orderTable);
        }

        // GET: Orders/Create
        public ActionResult Create()
        {
            ViewBag.cust_id = new SelectList(db.Customers, "id", "firstName");
            ViewBag.status_id = new SelectList(db.OrderStatus, "id", "status");
            ViewBag.payment_id = new SelectList(db.PaymentStatus, "id", "paymentAmount");
            ViewBag.prod_id = new SelectList(db.Products, "productId", "productName");
            return View();
        }

        // POST: Orders/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "id,cust_id,prod_id,order_Date,status_id,payment_id")] OrderTable orderTable)
        {
            if (ModelState.IsValid)
            {
                db.OrderTables.Add(orderTable);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.cust_id = new SelectList(db.Customers, "id", "firstName", orderTable.cust_id);
            ViewBag.status_id = new SelectList(db.OrderStatus, "id", "status", orderTable.status_id);
            ViewBag.payment_id = new SelectList(db.PaymentStatus, "id", "paymentAmount", orderTable.payment_id);
            ViewBag.prod_id = new SelectList(db.Products, "productId", "productName", orderTable.prod_id);
            return View(orderTable);
        }

        // GET: Orders/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            OrderTable orderTable = db.OrderTables.Find(id);
            if (orderTable == null)
            {
                return HttpNotFound();
            }
            ViewBag.cust_id = new SelectList(db.Customers, "id", "firstName", orderTable.cust_id);
            ViewBag.status_id = new SelectList(db.OrderStatus, "id", "status", orderTable.status_id);
            ViewBag.payment_id = new SelectList(db.PaymentStatus, "id", "paymentAmount", orderTable.payment_id);
            ViewBag.prod_id = new SelectList(db.Products, "productId", "productName", orderTable.prod_id);
            return View(orderTable);
        }

        // POST: Orders/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id,cust_id,prod_id,order_Date,status_id,payment_id")] OrderTable orderTable)
        {
            if (ModelState.IsValid)
            {
                db.Entry(orderTable).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.cust_id = new SelectList(db.Customers, "id", "firstName", orderTable.cust_id);
            ViewBag.status_id = new SelectList(db.OrderStatus, "id", "status", orderTable.status_id);
            ViewBag.payment_id = new SelectList(db.PaymentStatus, "id", "paymentAmount", orderTable.payment_id);
            ViewBag.prod_id = new SelectList(db.Products, "productId", "productName", orderTable.prod_id);
            return View(orderTable);
        }

        // GET: Orders/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            OrderTable orderTable = db.OrderTables.Find(id);
            if (orderTable == null)
            {
                return HttpNotFound();
            }
            return View(orderTable);
        }

        // POST: Orders/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            OrderTable orderTable = db.OrderTables.Find(id);
            db.OrderTables.Remove(orderTable);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
